#!/bin/sh
rm -f install.sh cleanup.sh mgr_update_1.1.21.tar.gz mgr_update_1.1.21.bin mgr_update_1.1.21.bin.tar.gz
