#!/bin/sh
rm -f install.sh cleanup.sh mgr_update_1.1.19.tar.gz mgr_update_1.1.19.bin mgr_update_1.1.19.bin.tar.gz
