#!/bin/sh
rm -f install.sh cleanup.sh mgr_update_1.1.20.tar.gz mgr_update_1.1.20.bin mgr_update_1.1.20.bin.tar.gz
